// Kiểm thử đăng ký tài khoản: người mới tự tạo tài khoản rồi mua hàng được ngay
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { useTestDatabase, useFakeBlob } from "./helpers.js";

process.env.AUTH_SECRET = "test-secret";
process.env.DEMO_LOGIN = "true";
process.env.AUTH_USERS = JSON.stringify([
  { username: "admin", password: "adminpass", role: "admin", name: "Quản trị viên" },
  { username: "user1", password: "pass1", role: "user", name: "Người dùng 1" }
]);

let server;
let baseUrl;

before(async () => {
  await useTestDatabase();
  useFakeBlob();
  const { default: app } = await import("../server.js");
  server = app.listen(0);
  await new Promise((resolve) => server.once("listening", resolve));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

after(() => server?.close());

async function call(path, { method = "GET", body, cookie } = {}) {
  const response = await fetch(baseUrl + path, {
    method,
    headers: { "Content-Type": "application/json", ...(cookie ? { Cookie: cookie } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body)
  });
  return { status: response.status, body: await response.json(), cookie: response.headers.get("set-cookie")?.split(";")[0] };
}

const register = (body) => call("/api/auth/register", { method: "POST", body });

test("đăng ký xong được đăng nhập luôn và mua được hàng", async () => {
  const r = await register({ name: "  Trần   Thị Bình ", username: "TranBinh", password: "matkhau123" });
  assert.equal(r.status, 201, JSON.stringify(r.body));
  assert.deepEqual(r.body.user, { username: "tranbinh", name: "Trần Thị Bình", role: "user" }, "tên đăng nhập viết thường, họ tên gọn khoảng trắng");
  assert.ok(r.cookie, "có cookie phiên");
  assert.equal(JSON.stringify(r.body).includes("scrypt"), false, "không bao giờ trả chuỗi băm mật khẩu");

  const me = await call("/api/auth/me", { cookie: r.cookie });
  assert.equal(me.body.user.username, "tranbinh");

  // user1 (tài khoản AUTH_USERS) đăng bán, tài khoản mới đăng ký mua
  const seller = (await call("/api/auth/login", { method: "POST", body: { username: "user1", password: "pass1" } })).cookie;
  const listing = await call("/api/listings", { method: "POST", cookie: seller, body: { name: "Tai nghe", price: 300_000 } });
  assert.equal(listing.status, 201);
  const order = await call("/api/orders", {
    method: "POST", cookie: r.cookie,
    body: { items: [{ listingId: listing.body.listing.id }], phone: "0901234567", address: "12 Nguyễn Huệ" }
  });
  assert.equal(order.status, 201, JSON.stringify(order.body));
  const mine = await call("/api/orders", { cookie: r.cookie });
  assert.equal(mine.body.purchases.length, 1);

  // tài khoản mới cũng tự đăng bán được
  const own = await call("/api/listings", { method: "POST", cookie: r.cookie, body: { name: "Sách cũ", price: 50_000 } });
  assert.equal(own.status, 201);
});

test("đăng xuất rồi đăng nhập lại bằng mật khẩu", async () => {
  await register({ name: "Lê Chi", username: "lechi", password: "abcdef" });
  const wrong = await call("/api/auth/login", { method: "POST", body: { username: "lechi", password: "sai-mat-khau" } });
  assert.equal(wrong.status, 401);
  const ok = await call("/api/auth/login", { method: "POST", body: { username: "LECHI", password: "abcdef" } });
  assert.equal(ok.status, 200);
  assert.equal(ok.body.user.name, "Lê Chi");
  const missing = await call("/api/auth/login", { method: "POST", body: { username: "khongtontai", password: "abcdef" } });
  assert.equal(missing.status, 401, "sai tên và sai mật khẩu báo cùng một lỗi");
  assert.equal(missing.body.error, wrong.body.error);
});

test("chặn trùng tên, tên hệ thống và dữ liệu không hợp lệ", async () => {
  await register({ name: "Phạm Dũng", username: "dungpham", password: "abcdef" });
  assert.equal((await register({ name: "Người khác", username: "DungPham", password: "123456" })).status, 409);
  assert.equal((await register({ name: "Giả admin", username: "admin", password: "123456" })).status, 409, "đã có trong AUTH_USERS");
  assert.equal((await register({ name: "Giả quản trị", username: "quantri", password: "123456" })).status, 400, "tên dành riêng");
  assert.equal((await register({ name: "Giả user1", username: "user1", password: "123456" })).status, 409, "trùng AUTH_USERS");
  assert.equal((await register({ name: "Ngắn", username: "ab", password: "123456" })).status, 400);
  assert.equal((await register({ name: "Có dấu", username: "nguyễn", password: "123456" })).status, 400);
  assert.equal((await register({ name: "Khoảng trắng", username: "a b c", password: "123456" })).status, 400);
  assert.equal((await register({ name: "Mật khẩu ngắn", username: "matkhaungan", password: "123" })).status, 400);
  assert.equal((await register({ name: "Trùng", username: "trungten", password: "trungten" })).status, 400);
  assert.equal((await register({ name: "X", username: "tenquangan", password: "123456" })).status, 400, "họ tên quá ngắn");
  const res = await register({ name: "Nhập thiếu" });
  assert.equal(res.status, 400);
  assert.match(res.body.error, /Tên đăng nhập/);
});

test("tài khoản đăng ký không phải admin và không bị lộ qua đăng nhập nhanh", async () => {
  const r = await register({ name: "Hoàng Em", username: "hoangem", password: "abcdef", role: "admin" });
  assert.equal(r.status, 201);
  assert.equal(r.body.user.role, "user", "không tự gán được quyền admin");
  assert.equal((await call("/api/admin/stats", { cookie: r.cookie })).status, 403);

  const demo = await call("/api/auth/demo-accounts");
  assert.equal(demo.body.accounts.some(a => a.username === "hoangem"), false);
  assert.equal((await call("/api/auth/demo-login", { method: "POST", body: { username: "hoangem" } })).status, 404);
});

test("cookie giả mạo không đăng nhập được vào tài khoản đăng ký", async () => {
  await register({ name: "Võ Giang", username: "vogiang", password: "abcdef" });
  const payload = Buffer.from(JSON.stringify({ u: "vogiang", v: "x", exp: Date.now() + 1e6 })).toString("base64url");
  const me = await call("/api/auth/me", { cookie: `reloop_session=${payload}.chu-ky-gia` });
  assert.equal(me.body.user, null);
});
